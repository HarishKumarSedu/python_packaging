```
python setup.py sdist 
python setup.py install 
python setup.py register 
```